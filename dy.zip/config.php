<?php

$config = array();

$config['site_title'] = '&#1578;&#1581;&#1605;&#1610;&#1604; &#1601;&#1610;&#1583;&#1610;&#1608; &#1610;&#1608;&#1578;&#1610;&#1608;&#1576;'; // Website Title

$config['site_meta'] = '&#1575;&#1601;&#1590;&#1604; &#1605;&#1608;&#1602;&#1593; &#1604;&#1578;&#1581;&#1605;&#1610;&#1604; &#1575;&#1604;&#1601;&#1610;&#1583;&#1610;&#1608; &#1605;&#1606; &#1575;&#1604;&#1610;&#1608;&#1578;&#1610;&#1608;&#1576; &#1576;&#1580;&#1608;&#1583;&#1575;&#1578; &#1605;&#1578;&#1593;&#1583;&#1583;&#1577; &#1608; &#1585;&#1608;&#1575;&#1576;&#1591; &#1605;&#1576;&#1575;&#1588;&#1585;&#1577; '; // Site meta description

$config['site_url'] = 'http://video-downloader.epizy.com/'; // Site url with slash

$config['enable_ads'] = true; // Enable ads? true / false

$config['server_email'] = 'support@catonite.website'; // Your server email address where all emails will be sent FROM

$config['contact_email'] = 'youremail here'; // Your personal email to receive all contact email

$config['ads_code'] = '' //paste your ad code into the quotemarks

?>
